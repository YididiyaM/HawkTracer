//React Core
import React, { useState } from "react";
import { useParams } from "react-router-dom";

//Components
import Header from "../Organisms/Header";
import Package from "../Organisms/Package";

export default function ResultsPage({information}){

   //Data
   const {query} = useParams();
  const checkItem = information.filter((item)=> item.parcel_id.match(query))[0];
return <div className="ResultsPage">
    <Header />
    
    <div className="container"> 
    <Package checkItem={checkItem}/>
    </div>
    
</div>
}